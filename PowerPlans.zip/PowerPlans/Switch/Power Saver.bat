:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

:: Enabling Power Saver.
powercfg -setactive a1841308-3541-4fab-bc81-f71556f20b4a >nul 2>&1
exit