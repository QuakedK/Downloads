:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

:: Read Power Plan GUID.
set /p GUID=<"C:\Power Plans\GUIDs\Quaked Idle On.txt"

:: Enabling Quaked Ultimate Performance.
powercfg -setactive %GUID% >nul 2>&1
exit